package jogo;
import java.awt.AWTException;
import java.io.IOException;
import java.util.Scanner;

public class Jogo {

    public static void main(String[] args) throws IOException, AWTException, InterruptedException {
         int jogadores, op = 0;
        
    Scanner scan = new Scanner(System.in);
    System.out.println("Digite 1 para Single Player e 2 para Multiplayer");
    jogadores = scan.nextInt();
    
    if (jogadores == 1){
        
     do{
      bot2.limpar();
      bot2.tabuleirao();
      bot2.jogao();
            System.out.println("Digite 1 para reiniciar ou 2 para sair: ");
            op = scan.nextInt();
     }while(op==1);
    
  }
    
    
    else{
        do{

         tabuleiro.limpar();
         tabuleiro.tabuleirao();
         tabuleiro.jogao();
            System.out.println("Digite 1 para reiniciar ou 2 para sair: ");
            op = scan.nextInt();
        }while(op==1);
    } 
}
}
