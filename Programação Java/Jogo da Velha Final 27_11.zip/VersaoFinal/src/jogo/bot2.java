
package jogo;
import java.util.Random;
import java.util.Scanner;

public class bot2 {
    

    
    public static String[][] m = {{"1","2","3"},
                            {"4","5","6"},
                            {"7","8","9"}};

    public static void jogao() throws InterruptedException{
        Scanner scan = new Scanner(System.in);
        int validar = 0, jogadas = 0;
        String posicao;
        Random r = new Random();
        int valor;
        
        while(true){
        do{
            System.out.println("Jogador 1, Escolha sua posicao: ");
            posicao = scan.next();
            while(!Valido(posicao)){
                System.out.println("Jogada inválida, tente novamente.");
                System.out.println("Jogador 1, Escolha sua posicao: ");
                posicao = scan.next();
                validar = 0;
            }
            Jogada(posicao, "X");
            validar = 1;
        }while(validar == 0);
        jogadas++;
        validar = 0;
        tabuleirao();
        if(!Ganhou(jogadas).equals("null")){
            break;
        }
        do{
            System.out.println("Vez do bot! ");
            
            Thread.sleep(2000);
            
            //pegar posição
          do {
               
            do{ 
               valor =  r.nextInt(9);
            } while(valor == 0);
             
            if(valor == 1){
                posicao = "1";
            }
            else if(valor == 2){
                posicao = "2";
            }
            else if(valor == 3){
                posicao = "3";
            }
            else if(valor == 4){
                posicao = "4";
            }
            else if(valor == 5){
                posicao = "5";
            }
            else if(valor == 6){
                posicao = "6";
            }
            else if(valor == 7){
                posicao = "7";
            }
            else if(valor == 8){
                posicao = "8";
            }
            else if(valor == 9){
                posicao = "9";
            }
          
            
                validar = 0;
            
          } while(!Valido(posicao));
              
            
            Jogada(posicao, "O");
            validar = 1;
        }while(validar == 0);
        jogadas++;
        validar = 0;
        tabuleirao();
         if(!Ganhou(jogadas).equals("null")){
            break;
         }
        }
        if(Ganhou(jogadas).equals("empate")){
            System.out.println("O "+Ganhou(jogadas)+" ocorreu");
        }
        else{
        System.out.println("O "+Ganhou(jogadas)+" venceu");
        }
    }
    
    
    
    
    public static  String tabuleirao(){
        
      
        
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                
            if(i == 0 && j == 2 || i == 1 && j == 2 || i == 2 && j == 2 )
            {
               System.out.printf(m[i][j]);  
            }           
            else{      
            System.out.printf( m[i][j] + "|"); 

            } 
        }
            System.out.println("\n");
        }
        return null;
    }
    public static boolean Valido(String p){
        for(int li=0; li<3; li++){
            for(int co=0; co<3; co++){
                if(m[li][co].equals(p))
                   return true;
            }
        }
        return false;
    }
    public static void Jogada(String p, String j){
        if(p.equals("1"))
            m[0][0] = j;
        else if(p.equals("2"))
            m[0][1] = j;
        else if(p.equals("3"))
            m[0][2] = j;
        else if(p.equals("4"))
            m[1][0] = j;
        else if(p.equals("5"))
            m[1][1] = j;
        else if(p.equals("6"))
            m[1][2] = j;
        else if(p.equals("7"))
            m[2][0] = j;
        else if(p.equals("8"))
            m[2][1] = j;
        else if(p.equals("9"))
            m[2][2] = j;
    }
    public static String Ganhou(int jogadas){
        String[] T = new String[8];
        String vencedor = "null";
        if(jogadas==9){
            vencedor = "empate";
        }
        T[0] = m[0][0] + m[0][1] + m[0][2];
        T[1] = m[1][0] + m[1][1] + m[1][2];
        T[2] = m[2][0] + m[2][1] + m[2][2];
        
        T[3] = m[0][0] + m[1][0] + m[2][0];
        T[4] = m[0][1] + m[1][1] + m[2][1];
        T[5] = m[0][2] + m[1][2] + m[2][2];
        
        T[6] = m[0][0] + m[1][1] + m[2][2];
        T[7] = m[0][2] + m[1][1] + m[2][0];
        
        for(int i=0; i<T.length; i++){
            if(T[i].equals("XXX")){
                vencedor = "Jogador 1";
            }
            else if(T[i].equals("OOO")){
                vencedor = "Jogador 2";
            }
        }
        return vencedor;
    }

    public static void limpar(){
        m[0][0] = "1";
        m[0][1] = "2";
        m[0][2] = "3";
        m[1][0] = "4";
        m[1][1] = "5";
        m[1][2] = "6";
        m[2][0] = "7";
        m[2][1] = "8";
        m[2][2] = "9";
    
    }
}
